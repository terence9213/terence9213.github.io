﻿window.onload = function () {
    console.log("Page load");
    Utils.Init();
}

console.log("PRELOAD");
var Utils = {
    TIMER: 0,
    //CANVAS OVERLAY & ANIMATIONS
    Canvas: {
        ElapsedTime: 0,
        LastFrameTimeStamp: null,
        FrameCounter: 0,
        FPS: 0,
        FPSDisplay: 0,
        DilationFactor: 1,
        ShowStats: true,
        canvas: null,
        ctx: null,
        CtxTool: {
            Clear: function () {
                Utils.Canvas.ctx.clearRect(0, 0, Utils.Canvas.canvas.width, Utils.Canvas.canvas.height);
            },
            Line: function (ox, oy, tx, ty, w, clr) {
                Utils.Canvas.ctx.beginPath();
                Utils.Canvas.ctx.lineWidth = w;
                Utils.Canvas.ctx.strokeStyle = clr;
                Utils.Canvas.ctx.moveTo(ox, oy);
                Utils.Canvas.ctx.lineTo(tx, ty);
                Utils.Canvas.ctx.closePath();
                Utils.Canvas.ctx.stroke();
            },
            Circle: function (x, y, r, clr, alpha) {
                Utils.Canvas.ctx.globalAlpha = alpha ? alpha : 1;
                Utils.Canvas.ctx.beginPath();
                Utils.Canvas.ctx.fillStyle = clr;
                Utils.Canvas.ctx.arc(x, y, r, 0, Math.PI * 2, false);
                Utils.Canvas.ctx.fill();
                Utils.Canvas.ctx.closePath();
                Utils.Canvas.ctx.globalAlpha = 1;
            },
            Text: function (text, x, y, align, size, clr) {
                Utils.Canvas.ctx.font = size + "px Courier";
                Utils.Canvas.ctx.textAlign = align;
                Utils.Canvas.ctx.fillStyle = clr;
                Utils.Canvas.ctx.fillText(text, x, y);
            },
            BasicGradient: function (x, y, r1, r2, alpha) {
                Utils.Canvas.ctx.globalAlpha = alpha ? alpha : 1;
                //Utils.Canvas.ctx.globalCompositeOperation = "destination-out";
                var gradient = Utils.Canvas.ctx.createRadialGradient(x, y, r1, x, y, r2);
                gradient.addColorStop(0, "rgba(255, 150, 0, 0.7)");
                gradient.addColorStop(0.3, "rgba(255, 255, 100, 0.4)");
                gradient.addColorStop(0.8, "rgba(255, 255, 50, 0.15)");
                gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
                //gradient.addColorStop(0, "white");
                //gradient.addColorStop(0.5, "red");
                //gradient.addColorStop(1, "pink");
                Utils.Canvas.ctx.fillStyle = gradient;
                Utils.Canvas.ctx.fillRect(x - r2, y - r2, r2 * 2, r2 * 2);
                Utils.Canvas.ctx.globalAlpha = 1;
            },
            CreateGradient: function (ox, oy, tx, ty, clrStop) {
                var gradient = Utils.Canvas.ctx.createLinearGradient(ox, oy, tx, ty);
                gradient.addColorStop(0, clrStop);
                //gradient.addColorStop(0.8, "rgba(255, 255, 255, 0)");
                gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
                return gradient;
            }
        },
        SetDilationFactor: function (factor) {
            Utils.Canvas.DilationFactor = factor;
        },
        //MAIN RENDER FUNCTION
        RenderFrame: function () {
            //FPS CALCULATION
            var DELTA = Utils.Canvas.LastFrameTimeStamp ? performance.now() - Utils.Canvas.LastFrameTimeStamp : 0;
            Utils.Canvas.ElapsedTime += DELTA * Utils.Canvas.DilationFactor;
            Utils.Canvas.FPS = Math.floor(1000 / DELTA);
            if (Utils.Canvas.FPS <= 25) { console.log("FPS Drop : " + Utils.Canvas.FPS); }
            Utils.Canvas.LastFrameTimeStamp = performance.now();
            Utils.Canvas.FrameCounter++;
            if (Utils.Canvas.FrameCounter === 12) {
                Utils.Canvas.FrameCounter = 0;
                Utils.Canvas.FPSDisplay = Utils.Canvas.FPS;
            }
            //console.log(DELTA);
            Utils.Canvas.CtxTool.Clear();
            
            //Stats overlay
            Utils.Canvas.DrawStatsOverlay();

            // -*-*-*-*-*-*-*-*-*-*-*-* ANIMATIONS -*-*-*-*-*-*-*-*-*-*-*-* \\
            Utils.Canvas.Animation.FInterface.FrameTick(DELTA);

            Utils.Canvas.Animation.DrawAll(DELTA * Utils.Canvas.DilationFactor);


            window.requestAnimationFrame(Utils.Canvas.RenderFrame);
        },

        //Canvas stats overlay
        DrawStatsOverlay: function () {
            if (Utils.Canvas.ShowStats) {
                Utils.Canvas.CtxTool.Text("FPS : " + Utils.Canvas.FPSDisplay, 20, 20, "left", 15, "white");

                Utils.Canvas.CtxTool.Text("Time Dilation Factor : " + Utils.Canvas.DilationFactor, 20, 35, "left", 15, "white");
                Utils.Canvas.CtxTool.Text("Mouse Position : {X:" + Utils.UI.MousePos.x + " Y:" + Utils.UI.MousePos.y + "}", 20, 50, "left", 15, "white");
                //Utils.Canvas.CtxTool.Text("Performance.NOW() : " + performance.now() , 20, 65, "left", 15, "white");
                //Utils.Canvas.CtxTool.Text("ElpasedTime       : " + Utils.Canvas.ElapsedTime , 20, 80, "left", 15, "white");

                //FInterface Trigger Active Indicator
                Utils.Canvas.CtxTool.Circle(window.innerWidth - 15, 15, 10, Utils.Canvas.Animation.FInterface.Active ? "Green" : "Red", 1);
            }
        },

        //ALL ANIMATIONS HERE
        Animation: {
            MasterArray: [],
            //Draw ALL objects in MasterArray
            DrawAll: function (delta) {
                for (var i = 0; i < Utils.Canvas.Animation.MasterArray.length; i++) {
                    var animObj = Utils.Canvas.Animation.MasterArray[i];
                    animObj.Draw(delta, i);
                    if (!animObj.Active) {
                        //Animation complete [splice animObj from MasterArray & shift iteration index back]
                        Utils.Canvas.Animation.MasterArray.splice(i, 1);
                        if (i >= 0) { i-- };
                    };
                }
            },
            //OLD Fireworks 
            Fireworks: {
                Active: false,
                Pos: { x: 0, y: 0 },
                Particles: [],
                Start: function (x, y) {
                    if (!Utils.Canvas.Animation.Fireworks.Active) {
                        Utils.Canvas.Animation.Fireworks.Active = true;
                        Utils.Canvas.Animation.Fireworks.Pos = { x: x, y: y };

                        //Generate Particles [100]
                        for (var i = 0; i < 100; i++) {
                            //var acceleration = Utils.Draw.Rand.GenerateRandomFloat(0.01, 0.1);
                            var maxSpeed = Utils.Rand.Float(0.5, 10);
                            var size = Utils.Rand.Float(1, 5);
                            var vectorX = Utils.Rand.Float(-1, 1);
                            var vectorY = Utils.Rand.Float(-1, 1);
                            var rgb_r = Utils.Rand.Float(200, 255);
                            var rgb_g = Utils.Rand.Float(0, 255);
                            var rgb_b = Utils.Rand.Float(0, 255);
                            Utils.Canvas.Animation.Fireworks.Particles.push({
                                index: i,
                                timeStart: performance.now(),
                                pos: { x: x, y: y },
                                vector: { ox: x, oy: y, x: vectorX, y: vectorY },
                                speed: 0,
                                maxSpeed: maxSpeed,
                                acceleration: 0.2,
                                deceleration: 0.1,
                                halfLife: 500,
                                color: "rgb(" + rgb_r + "," + rgb_g + "," + 0 + ")",
                                alpha: 1,
                                size: size
                            });
                        }

                    }
                },
                End: function () {
                    Utils.Canvas.Animation.Fireworks.Particles = [];
                },
                DrawFireworks: function (delta) {
                    if (Utils.Canvas.Animation.Fireworks.Active) {
                        var fwObj = Utils.Canvas.Animation.Fireworks;
                        //SIZE RATE = 25px/second
                        //fwObj.Size += (50 / 1000) * delta;
                        //Utils.Canvas.CtxTool.Circle(fwObj.Pos.x, fwObj.Pos.y, fwObj.Size, "red");

                        for (var i = 0; i < fwObj.Particles.length; i++) {
                            var particle = fwObj.Particles[i];
                            //console.log(particle);

                            //Particle Decay
                            if (performance.now() >= particle.timeStart + particle.halfLife) {
                                if (particle.speed > 0) {
                                    particle.speed -= particle.deceleration;
                                    if (particle.speed < 0) {
                                        particle.speed = 0.05;
                                        particle.vector.x = 0;
                                        particle.vector.y = 1;
                                    }
                                }
                                if (performance.now() >= particle.timeStart + particle.halfLife + 1000) {
                                    if (particle.alpha > 0) {
                                        particle.alpha -= 0.01;
                                        if (particle.alpha < 0) { particle.alpha = 0; }
                                    }
                                }
                            }
                            //Particle Acceleration
                            else if (particle.speed < particle.maxSpeed) {
                                particle.speed += particle.acceleration;
                            }


                            particle.pos.x += delta * particle.speed * particle.vector.x;
                            particle.pos.y += delta * particle.speed * particle.vector.y

                            if (particle.alpha > 0) {
                                fwObj.Active = true;
                                Utils.Canvas.CtxTool.Circle(particle.pos.x, particle.pos.y, particle.size, particle.color, particle.alpha);
                            }
                            else {
                                fwObj.Active = false;
                            }
                        }

                        if (!fwObj.Active) {
                            fwObj.End();
                        }

                    }
                }
            },

            //FIREWORKS ANIMATION INTERFACE
            FInterface: {
                Active: false,
                Trigger: false,
                LaunchInterval: 100,
                PreviousLaunchTime: null,
                TriggerDown: function () {
                    Utils.Canvas.Animation.FInterface.Trigger = true;
                },
                TriggerUp: function () {
                    Utils.Canvas.Animation.FInterface.Trigger = false;
                },
                //Frame Dependant Tick
                FrameTick: function (delta) {
                    if (Utils.Canvas.Animation.FInterface.Active && Utils.Canvas.Animation.FInterface.Trigger) {
                        Utils.Canvas.Animation.FInterface.TryLaunch(delta);
                    }
                },
                //Launch if Interval has passed
                TryLaunch: function () {
                    if (Utils.Canvas.Animation.FInterface.PreviousLaunchTime === null || performance.now() >= Utils.Canvas.Animation.FInterface.PreviousLaunchTime + Utils.Canvas.Animation.FInterface.LaunchInterval / Utils.Canvas.DilationFactor) {
                        var ff = new Utils.Canvas.Animation.FFireworks();
                        ff.Start(Utils.UI.MousePos.x, Utils.UI.MousePos.y, 0, false);
                        Utils.Canvas.Animation.FInterface.PreviousLaunchTime = performance.now();
                    }
                },
                Launch: function (animationSeq) {
                    var ff = new Utils.Canvas.Animation.FFireworks(animationSeq.ox, animationSeq.oy);
                    ff.Start(animationSeq.x, animationSeq.y, animationSeq.delay, animationSeq.noLaunch);
                },
                MultiLaunch: function (tier) {
                    var animationSeqArray = Utils.Sequence.Animations[tier].DrawEnd;
                    for (var i = 0; i < animationSeqArray.length; i++) {
                        Utils.Canvas.Animation.FInterface.Launch(animationSeqArray[i]);
                    }
                }
            },

            //Animation Template Objects
            FFireworks: function (ox, oy) {
                this.ox = (ox === null || ox === undefined) ? Utils.Canvas.canvas.width / 2 : ox;
                this.oy = (oy === null || oy === undefined) ? Utils.Canvas.canvas.height : oy;
                this.Active = false;
                //this.LaunchVector = { x: 0, y: 0 };
                this.Delay = 0;
                this.StartTime = 0;
                this.Pos = { x: 0, y: 0 };
                this.Particles = [];
                this.LaunchParticle = null;
                this.Start = function (x, y, delay, noLaunch) {
                    if (!this.Active) {
                        this.Active = true;
                        this.Pos = { x: x, y: y };
                        this.StartTime = Utils.Canvas.ElapsedTime;
                        //this.ElapsedTime = 0;
                        this.Delay = delay;

                        //Calculate Launch Vector
                        var dx = x - this.ox;
                        var dy = y - this.oy;
                        var dist = Math.sqrt(dx * dx + dy * dy);
                        var launchVector = { x: dx / dist, y: dy / dist };

                        //console.log(launchVector);
                        //Initialise Launch Projectile
                        this.LaunchParticle = {
                            //Active: true,
                            State: noLaunch ? 0 : 1, // [0 : done] [1 : Launch] [2 : Explode] 
                            Pos: { x: this.ox, y: this.oy },
                            Vector: launchVector,
                            Speed: 1100, // (px/s)
                            TargetDist: dist,
                            TravelledDist: 0,
                            Explosion: {
                                State: noLaunch ? 1 : 0, // [0 : done] [1 : Expand] [2 : Contract] 
                                Radius: { r1: 1, r2: 5 },
                                Acceleration: { r1: 0.07, r2: 0.28 },
                                Deceleration: { r1: 0.6, r2: 0.9 },
                                Speed: { r1: 0, r2: 0, r1AccPhase: true, r2AccPhase: true, r1Max: 15, r2Max: 20 },
                                HalfLife: 20,
                                AlphaDecayRate: 0.1,
                                Alpha: 1
                            }
                        };

                        if (noLaunch) {
                            this.GenerateParticles(delay);
                        }

                        Utils.Canvas.Animation.MasterArray.push(this);
                        //PLAY WOOSH SOUND CLIP
                        Utils.Synth.playClip(Utils.Synth.clip.WOOSH);
                    }
                };
                this.GenerateParticles = function (noLaunchDelay) {
                    //Generate Particles
                    var particleCount = Utils.Rand.Int(30, 50);
                    for (var i = 0; i < particleCount; i++) {
                        var maxSpeed = Utils.Rand.Float(0.5, 2);
                        var halfLife = Utils.Rand.Int(350, 550); // default 500
                        var decay = Utils.Rand.Int(200, 400); // default 1000
                        var size = Utils.Rand.Float(0.1, 2.8);
                        var angle = Math.random() * Math.PI * 2;
                        //var vectorX = Utils.Rand.Float(-1, 1);
                        //var vectorY = Utils.Rand.Float(-1, 1);
                        var vectorX = Math.cos(angle) * Utils.Rand.Float(-1, 1);
                        var vectorY = Math.cos(angle) * Utils.Rand.Float(-1, 1);
                        var rgb_r = Utils.Rand.Float(200, 255);
                        var rgb_g = Utils.Rand.Float(0, 255);
                        var rgb_b = Utils.Rand.Float(0, 255);
                        this.Particles.push({
                            index: i,
                            timeStart: (noLaunchDelay === undefined || noLaunchDelay === null) ? performance.now() : performance.now() + noLaunchDelay,
                            pos: { x: this.Pos.x, y: this.Pos.y },
                            vector: { x: vectorX, y: vectorY },
                            speed: 2,
                            maxSpeed: maxSpeed,
                            acceleration: 0.1,
                            deceleration: 0.2,
                            gravity: 0.05,
                            halfLife: halfLife,
                            decay: decay,
                            color: "rgb(" + rgb_r + "," + rgb_g + "," + 0 + ")",
                            alphaDecayRate: 0.015,// * Utils.Canvas.DilationFactor,
                            alpha: 1,
                            size: size,
                            dead: false
                        });
                    }
                    //console.log(this.Particles);
                    //PLAY EXPLOSION SOUND CLIP
                    Utils.Synth.playClip(Utils.Synth.clip.EXPLOSION1);
                };
                this.End = function (i) {
                    this.Particles = [];
                    Utils.Canvas.Animation.MasterArray.splice(i, 1);
                };
                this.Draw = function (delta, index) {
                    //this.ElapsedTime += delta * Utils.Canvas.DilationFactor;
                    //if (performance.now() >= this.StartTime + this.Delay) {
                    if (Utils.Canvas.ElapsedTime >= this.StartTime + this.Delay) {
                        this.launched = true;
                        //Animate Launch Particle
                        if (this.LaunchParticle.State === 1) {
                            if (this.LaunchParticle.TravelledDist < this.LaunchParticle.TargetDist) {
                                var dist = this.LaunchParticle.Speed / 1000 * delta;
                                this.LaunchParticle.Pos.x += this.LaunchParticle.Vector.x * dist;
                                this.LaunchParticle.Pos.y += this.LaunchParticle.Vector.y * dist;
                                var dx = this.LaunchParticle.Pos.x - this.ox;
                                var dy = this.LaunchParticle.Pos.y - this.oy;
                                this.LaunchParticle.TravelledDist = Math.sqrt(dx * dx + dy * dy);
                                //DRAW
                                //Main launch particle
                                Utils.Canvas.CtxTool.Line(this.LaunchParticle.Pos.x, this.LaunchParticle.Pos.y,
                                    this.LaunchParticle.Pos.x - this.LaunchParticle.Vector.x * 25,
                                    this.LaunchParticle.Pos.y - this.LaunchParticle.Vector.y * 25, 2, "yellow");
                                //Launch Particle Head
                                Utils.Canvas.CtxTool.Circle(this.LaunchParticle.Pos.x, this.LaunchParticle.Pos.y, 1.5, "red", 1);
                                //Gradient for launch particle trail
                                var grad = Utils.Canvas.CtxTool.CreateGradient(
                                    this.LaunchParticle.Pos.x - this.LaunchParticle.Vector.x * 25, this.LaunchParticle.Pos.y - this.LaunchParticle.Vector.y * 25,
                                    this.LaunchParticle.Pos.x - this.LaunchParticle.Vector.x * 200, this.LaunchParticle.Pos.y - this.LaunchParticle.Vector.y * 200,
                                    "rgba(250, 200, 125, 0.7)");
                                //Launch Particle Trail
                                Utils.Canvas.CtxTool.Line(
                                    this.LaunchParticle.Pos.x - this.LaunchParticle.Vector.x * 25, this.LaunchParticle.Pos.y - this.LaunchParticle.Vector.y * 25,
                                    this.LaunchParticle.Pos.x - this.LaunchParticle.Vector.x * 200, this.LaunchParticle.Pos.y - this.LaunchParticle.Vector.y * 200,
                                    3, grad);

                                
                            }
                            else {
                                //Initialise Explosion
                                this.LaunchParticle.Explosion.State = 1;
                                this.LaunchParticle.State = 2;
                                this.GenerateParticles();
                            }
                        }
                        //Animate Firework Particles and Explosion
                        else {
                            //Explosion
                            if (this.LaunchParticle.Explosion.State !== 0) {
                                //R1 SPD Calculation
                                var r1Spd = null;
                                if (this.LaunchParticle.Explosion.Speed.r1AccPhase) {
                                    //Accelerate r1 spd
                                    r1Spd = this.LaunchParticle.Explosion.Speed.r1 += this.LaunchParticle.Explosion.Acceleration.r1 * Utils.Canvas.DilationFactor;
                                    if (r1Spd >= this.LaunchParticle.Explosion.Speed.r1Max) {
                                        this.LaunchParticle.Explosion.Speed.r1AccPhase = false;
                                    }
                                }
                                else {
                                    r1Spd = this.LaunchParticle.Explosion.Speed.r1
                                    //Decelerate r1 spd
                                    if (r1Spd >= 0) {
                                        r1Spd = this.LaunchParticle.Explosion.Speed.r1 -= this.LaunchParticle.Explosion.Deceleration.r1 * Utils.Canvas.DilationFactor;
                                        if (r1Spd < 0) { r1Spd = this.LaunchParticle.Explosion.Speed.r1 = 0; }
                                    }
                                }

                                //R2 SPD Calculation
                                var r2Spd = null;
                                if (this.LaunchParticle.Explosion.Speed.r2AccPhase) {
                                    //Accelerate r1 spd
                                    r2Spd = this.LaunchParticle.Explosion.Speed.r2 += this.LaunchParticle.Explosion.Acceleration.r2 * Utils.Canvas.DilationFactor;
                                    if (r2Spd >= this.LaunchParticle.Explosion.Speed.r2Max) {
                                        this.LaunchParticle.Explosion.Speed.r2AccPhase = false;
                                    }
                                }
                                else {
                                    r2Spd = this.LaunchParticle.Explosion.Speed.r2;
                                    //Decelerate r1 spd
                                    if (r2Spd >= 0) {
                                        r2Spd = this.LaunchParticle.Explosion.Speed.r2 -= this.LaunchParticle.Explosion.Deceleration.r2 * Utils.Canvas.DilationFactor;
                                        if (r2Spd < 0) { r2Spd = this.LaunchParticle.Explosion.Speed.r2 = 0; }
                                    }
                                }

                                //CALCULATE R1 & R2
                                var r1 = this.LaunchParticle.Explosion.Radius.r1 += r1Spd * delta;
                                var r2 = this.LaunchParticle.Explosion.Radius.r2 += r2Spd * delta;
                                
                                //Calculate ALPHA
                                var alpha = this.LaunchParticle.Explosion.Alpha
                                if (this.LaunchParticle.Explosion.State === 2 && alpha > 0) {
                                    //DECAY
                                    alpha = this.LaunchParticle.Explosion.Alpha -= this.LaunchParticle.Explosion.AlphaDecayRate * Utils.Canvas.DilationFactor;
                                }
                                else if (performance.now() >= this.StartTime + (this.LaunchParticle.Explosion.HalfLife / Utils.Canvas.DilationFactor)) {
                                    this.LaunchParticle.Explosion.State = 2;
                                }

                                if (alpha > 0) {
                                    Utils.Canvas.CtxTool.BasicGradient(this.Pos.x, this.Pos.y, r1, r2, alpha);
                                }

                            }
                            
                            this.Active = false;
                            //Particles
                            for (var i = 0; i < this.Particles.length; i++) {
                                var particle = this.Particles[i];
                                //console.log(particle);

                                //Particle HalfLife / Decay
                                if (performance.now() >= particle.timeStart + (particle.halfLife / Utils.Canvas.DilationFactor)) {
                                    //Particle Death
                                    if (!particle.dead && particle.speed > 0) {
                                        particle.speed -= particle.deceleration * Utils.Canvas.DilationFactor;
                                        if (particle.speed <= 0) {
                                            particle.dead = true;
                                            particle.speed = particle.gravity;
                                            particle.vector.x = 0;
                                            particle.vector.y = 1;
                                        }
                                    }
                                    //Decay
                                    if (performance.now() >= particle.timeStart + (particle.halfLife / Utils.Canvas.DilationFactor) + (particle.decay / Utils.Canvas.DilationFactor)) {
                                        if (particle.alpha > 0) {
                                            particle.alpha -= particle.alphaDecayRate * Utils.Canvas.DilationFactor;
                                            if (particle.alpha < 0) { particle.alpha = 0; }
                                        }
                                    }
                                }
                                //Particle Acceleration
                                else if (performance.now() >= particle.timeStart && particle.speed < particle.maxSpeed) {
                                    particle.speed += particle.acceleration * Utils.Canvas.DilationFactor;
                                }

                                particle.pos.x += delta * particle.speed * particle.vector.x;
                                particle.pos.y += delta * particle.speed * particle.vector.y

                                if (particle.alpha > 0) {
                                    this.Active = true;
                                    //console.log(particle.pos.x + " " + particle.pos.y + " " + particle.size + " " + particle.alpha);
                                    Utils.Canvas.CtxTool.Circle(particle.pos.x, particle.pos.y, particle.size, particle.color, particle.alpha);
                                }

                                if (!this.Active) {
                                    //this.End(i);
                                }
                            }
                        }
                    }

                };
            }
        }

    },

    Synth: null,

    //INITIALISE FUNCTION
    Init: function () {
        //INIT Audio Synth
        Utils.Synth = new AudioSynth();
        Utils.Synth.init();

        Utils.Elements.fileInput = document.getElementById("file-input");
        Utils.Elements.fileInput.addEventListener("change", Utils.Import.FileInputChange);

        //Get Element refferences
        Utils.Elements.background = document.getElementById("bg-effects");
        Utils.Elements.btn = document.getElementById("btn");
        Utils.Elements.currentWinner = document.getElementById("current-winner");
        Utils.Elements.nameList = document.getElementById("name-list");
        Utils.Elements.winnerList = document.getElementById("winner-list");

        //Set EventListeners
        Utils.Elements.btn.addEventListener("mousedown", Utils.UI.BtnClick);
        document.addEventListener("keydown", Utils.UI.KeyDown);
        document.addEventListener("mousedown", Utils.UI.MouseDown);
        document.addEventListener("mouseup", Utils.UI.MouseUp);
        document.addEventListener("mousemove", Utils.UI.MouseMove);

        //Generate BG Stars
        Utils.Effects.GenerateBGStars();
        Utils.Effects.InitShootingStars();

        //FILL NAME LIST
        for (var i = 0; i < Utils.NameList.length; i++) {
            var listElement = document.createElement("li");
            listElement.appendChild(document.createTextNode(Utils.NameList[i].name));
            listElement.id = "list" + i;
            Utils.Elements.nameList.appendChild(listElement);
        }

        //Init Sequencer
        Utils.Sequence.Init();
        //Init Draw function
        Utils.Draw.Init();

        //Init Canvas
        Utils.Canvas.canvas = document.getElementById("canvas");
        Utils.Canvas.ctx = Utils.Canvas.canvas.getContext("2d");
        //Utils.Canvas.canvas.width = 1366;
        //Utils.Canvas.canvas.width = 1024;
        Utils.Canvas.canvas.width = window.innerWidth;
        //Utils.Canvas.canvas.height = 657;
        //Utils.Canvas.canvas.height = 697;
        Utils.Canvas.canvas.height = window.innerHeight;
        Utils.Canvas.RenderFrame();
    },

    //DOCUMENT ELEMENT REFFERENCES
    Elements: {
        background: null,
        btn: null,
        currentWinner: null,
        nameList: null,
        winnerList: null,
        fileInput: null
    },

    //UI EVENT LISTENERS
    UI: {
        MousePos: { x: null, y: null },
        BtnClick: function (e) {
            e.preventDefault();
            Utils.Draw.StartDraw();
        },
        KeyDown: function (e) {
            //e.preventDefault();
            console.log(e.keyCode);
            if (e.ctrlKey) {
                switch (e.keyCode) {
                    case 83: //S Key
                        e.preventDefault();
                        //Trigger saving json
                        Utils.Export.GetWinnerListJSON();
                        break;
                    case 88: // X Key
                        Utils.Export.GetRawList();
                        break;
                    case 76: // L Key 
                        //Invoke File Input
                        Utils.Import.TriggerFileInputClick();
                        break;
                }
            }
            else {
                switch (e.keyCode) {
                    case 32: //SPACEBAR
                        //Utils.Draw.StartDraw2();
                        break;
                    case 13: // ENTER
                        //Utils.Draw.StartDraw2();
                        break;
                    case 39: //RIGHT ARROW
                        if (Utils.Canvas.DilationFactor < 1) {
                            //Utils.Canvas.DilationFactor += 0.01;
                            //Utils.Canvas.DilationFactor = Math.round(Utils.Canvas.DilationFactor * 100) / 100;
                            //document.getElementById("time-slider").value = Utils.Canvas.DilationFactor;
                        }
                        break;
                    case 37: //LEFT ARROW
                        if (Utils.Canvas.DilationFactor > 0) {
                            //Utils.Canvas.DilationFactor -= 0.01;
                            //Utils.Canvas.DilationFactor = Math.round(Utils.Canvas.DilationFactor * 100) / 100;
                            //document.getElementById("time-slider").value = Utils.Canvas.DilationFactor;
                        }
                        break;
                    case 116: //F5 (REFRESH)
                        //e.preventDefault();
                        if (window.confirm("Are you sure you want to refresh? \nWinner List will be lost!")) {

                        }
                        else {
                            e.preventDefault();
                        }
                        break;
                    case 70: // F Key (FInterface Trigger Active)
                        Utils.Canvas.Animation.FInterface.Active = !Utils.Canvas.Animation.FInterface.Active;
                        break;
                    case 68: // D Key
                    case 79: // O Key (Toggle Canvas Stats Overlay)
                        Utils.Canvas.ShowStats = !Utils.Canvas.ShowStats;
                        break;
                }
            }
            
        },
        MouseDown: function (e) {
            //console.log(e.x + " x " + e.y);
            //var fireworksAnimation = new Utils.Canvas.Animation.FFireworks();
            //fireworksAnimation.Start(e.x, e.y, 0, false);
            e.preventDefault();
            Utils.Canvas.Animation.FInterface.TriggerDown();
        },
        MouseUp: function (e) {
            Utils.Canvas.Animation.FInterface.TriggerUp();
        },
        MouseMove: function (e) {
            Utils.UI.MousePos.x = e.clientX;
            Utils.UI.MousePos.y = e.clientY;
        }
    },

    //LUCKY DRAW FUNCTIONS
    Draw: {
        DrawLock: false,
        CurrentTier: null,
        CurrentWinnerList: null,
        CurrentDrawCount: null,
        WinnerRank: 44,

        Init: function () {
            Utils.Draw.CurrentTier = 0;
            Utils.Draw.CurrentWinnerList = Utils.Sequence.Tier[Utils.Draw.CurrentTier];
            Utils.Draw.CurrentDrawCount = 0;

        },

        //MASTER DRAW START
        StartDraw: function () {
            Utils.TIMER = performance.now();
            console.log("Draw Start : " + Utils.TIMER);
            if (!Utils.Draw.DrawLock) {
                //LOCK DRAW
                Utils.Draw.DrawLock = true;
                //LOCK UI
                Utils.Draw.UIEvent.LockUI();

                //Start Drawing
                Utils.Draw.DrawWinners();
            }

        },

        //MASTER DRAW END
        DrawEnd: function () {
            console.log("DRAW END : " + (performance.now() - Utils.TIMER));
            //Trigger Animations
            var animationSeqArray = Utils.Sequence.Animations[Utils.Draw.CurrentTier].DrawEnd;
            for (var i = 0; i < animationSeqArray.length; i++) {
                var animationSeq = animationSeqArray[i];
                Utils.Canvas.Animation.FInterface.Launch(animationSeq);
            }

            //UNLOCK DRAW
            Utils.Draw.DrawLock = false;
            //UNLOCK UI
            Utils.Draw.UIEvent.UnlockUI();

            //ALL WINNERS FOR CURRENT TIER DRAWN
            console.log("ALL WINNERS FOR CURRENT TIER DRAWN");

            //RESET DRAW
            Utils.Draw.CurrentTier++;
            Utils.Draw.CurrentWinnerList = Utils.Sequence.Tier[Utils.Draw.CurrentTier];
            Utils.Draw.CurrentDrawCount = 0;

            //Reset Current Winner
            Utils.Draw.UIEvent.ResetCurrentWinner();

            //RELEASE UI (IF THERE ARE STILL DRAWS)
            if (Utils.Draw.CurrentTier < 4) {
                //release
            }
            else {
                //EXPORT WINNERLIST?
            }
        },

        DrawWinners: function () {
            //Initialise Iterator
            Utils.Draw.Iterator.Init();

            //Start recursive jump loop
            Utils.Draw.Iterator.Jump(function (winner) {
                //Trigger WINNER ANIMATION
                var animationSeqArray = Utils.Sequence.Animations[Utils.Draw.CurrentTier].SingleWinner;
                //var animationSeqArray = Utils.Sequence.Animations[Utils.Draw.CurrentTier].DrawEnd;
                for (var i = 0; i < animationSeqArray.length; i++) {
                    var animationSeq = animationSeqArray[i];
                    Utils.Canvas.Animation.FInterface.Launch(animationSeq);
                }

                //Add Winner to list
                //Utils.Draw.UIEvent.AddWinner(winner, Utils.Draw.CurrentTier);
                window.setTimeout(function () { Utils.Draw.UIEvent.AddWinner(winner, Utils.Draw.CurrentTier); }, Utils.Draw.Iterator.JumpInterval, winner)
                //One winner has been drawn
                console.log(winner);

                if (Utils.Draw.CurrentDrawCount < Utils.Draw.CurrentWinnerList.length - 1) {
                    //Incement currentDrawCount
                    Utils.Draw.CurrentDrawCount++;

                    //Calculate winner interval
                    var winnerInterval = Utils.Sequence.Iterator[Utils.Draw.CurrentTier].WinnerInterval;

                    if (Utils.Draw.CurrentTier === 4 && Utils.Draw.CurrentDrawCount === Utils.Draw.CurrentWinnerList.length - 1) {
                        console.log("FINAL WINNER");
                        //FINAL WINNER / GRAND WINNER
                        window.setTimeout(function () {
                            var finalWinner = Utils.Draw.CurrentWinnerList[Utils.Draw.CurrentDrawCount];
                            console.log(finalWinner);
                            //DISPLAY FINAL WINNER
                            Utils.Draw.UIEvent.NameJump(finalWinner.id, null);

                            //Trigger WINNER ANIMATION
                            var animationSeqArray = Utils.Sequence.Animations[Utils.Draw.CurrentTier].SingleWinner;
                            for (var i = 0; i < animationSeqArray.length; i++) {
                                var animationSeq = animationSeqArray[i];
                                Utils.Canvas.Animation.FInterface.Launch(animationSeq);
                            }
                            //Add Winner to list
                            Utils.Draw.UIEvent.AddWinner(finalWinner, Utils.Draw.CurrentTier);

                            //INVOKE FINAL END DRAW
                            var drawEndDelay = Utils.Sequence.Iterator[Utils.Draw.CurrentTier].DrawEndDelay;
                            window.setTimeout(Utils.Draw.DrawEnd, drawEndDelay);
                        }, winnerInterval);
                    }
                    else {
                        //RECURSE
                        window.setTimeout(Utils.Draw.DrawWinners, winnerInterval);
                    }

                    
                }
                else {
                    //All winners drawn
                    var drawEndDelay = Utils.Sequence.Iterator[Utils.Draw.CurrentTier].DrawEndDelay;
                    window.setTimeout(Utils.Draw.DrawEnd, drawEndDelay);
                }
            });
        },

        Iterator: {
            JumpCounter: null,
            JumpCounter_Target: null,
            Index_Target: null,
            Index_Current: null,
            Index_Previous: null,
            JumpInterval: 0,
            Init: function () {
                Utils.Draw.Iterator.JumpCounter = 0;
                Utils.Draw.Iterator.JumpCounter_Target = Utils.Sequence.Iterator[Utils.Draw.CurrentTier].JumpTarget;
                Utils.Draw.Iterator.JumpInterval = Utils.Sequence.Iterator[Utils.Draw.CurrentTier].Interval;
                var targetWinner = Utils.Draw.CurrentWinnerList[Utils.Draw.CurrentDrawCount];
                Utils.Draw.Iterator.Index_Target = targetWinner.id;
                Utils.Draw.Iterator.Index_Current = null;
                Utils.Draw.Iterator.Index_Previous = null;
                return targetWinner;
            },
            Jump: function (callback) {
                if (Utils.Draw.Iterator.Index_Current === null) {
                    Utils.Draw.Iterator.Index_Current = 0;
                    while (Utils.NameList[Utils.Draw.Iterator.Index_Current] !== null && Utils.NameList[Utils.Draw.Iterator.Index_Current].win) {
                        Utils.Draw.Iterator.Index_Current++;
                    }
                }

                //JUMP ANIMATIONS
                Utils.Draw.UIEvent.NameJump(Utils.Draw.Iterator.Index_Current, Utils.Draw.Iterator.Index_Previous);

                //Calculate jump interval
                if (Utils.Sequence.Iterator[Utils.Draw.CurrentTier].JumpIntervalModifier) {
                    //Utils.Draw.Iterator.JumpInterval += 10;
                    Utils.Sequence.Iterator[Utils.Draw.CurrentTier].JumpIntervalModifier();
                }

                //console.log(Utils.Draw.Iterator);
                //RECURSE
                if (Utils.Draw.Iterator.JumpCounter < Utils.Draw.Iterator.JumpCounter_Target || Utils.Draw.Iterator.Index_Current !== Utils.Draw.Iterator.Index_Target) {
                    Utils.Draw.Iterator.JumpCounter++;
                    Utils.Draw.Iterator.Index_Previous = Utils.Draw.Iterator.Index_Current;
                    Utils.Draw.Iterator.Index_Current++;
                    //LOOP BACK TO 0
                    if (Utils.Draw.Iterator.Index_Current > Utils.NameList.length - 1) {
                        Utils.Draw.Iterator.Index_Current = 0;
                    }
                    //SKIP WINNERS
                    while (Utils.NameList[Utils.Draw.Iterator.Index_Current] !== null && Utils.NameList[Utils.Draw.Iterator.Index_Current].win) {
                        Utils.Draw.Iterator.Index_Current++;
                        //LOOP BACK TO 0
                        if (Utils.Draw.Iterator.Index_Current > Utils.NameList.length - 1) {
                            Utils.Draw.Iterator.Index_Current = 0;
                            while (Utils.NameList[Utils.Draw.Iterator.Index_Current] !== null && Utils.NameList[Utils.Draw.Iterator.Index_Current].win) {
                                Utils.Draw.Iterator.Index_Current++;
                            }
                        }
                    }

                    window.setTimeout(function () { Utils.Draw.Iterator.Jump(callback); }, Utils.Draw.Iterator.JumpInterval);
                }
                else if (Utils.Draw.Iterator.Index_Current === Utils.Draw.Iterator.Index_Target) {
                    Utils.NameList[Utils.Draw.Iterator.Index_Current].win = true;
                    //Iterations done : Callback
                    callback(Utils.NameList[Utils.Draw.Iterator.Index_Current]);
                }
            }
        },


        //UI EVENT
        UIEvent: {
            LockUI: function () {
                Utils.Elements.btn.classList.add("btn-lock");
            },
            UnlockUI: function () {
                Utils.Elements.btn.classList.remove("btn-lock");
            },

            ResetCurrentWinner: function () {
                Utils.Elements.currentWinner.innerText = "Winners";
            },
            NameJump: function (targetID, previousID) {
                //console.log("JUMP to " + targetID + " from " + previousID)
                if (previousID != null) { document.getElementById("list" + previousID).classList.remove("winner-li-tier" + Utils.Draw.CurrentTier); }
                document.getElementById("list" + targetID).classList.add("winner-li-tier" + Utils.Draw.CurrentTier);
                Utils.Elements.currentWinner.innerText = Utils.NameList[targetID].name;
            },
            AddWinner: function (winner, tier) {
                document.getElementById("list" + winner.id).classList.add("winner-li-disabled");

                var winnerElement = document.createElement("li");
                winnerElement.classList.add("winner-li-tier" + Utils.Draw.CurrentTier);
                winnerElement.classList.add("winner-li-blink");
                var winnerRank = document.createElement("span");
                var winnerName = document.createElement("span");
                winnerRank.appendChild(document.createTextNode(Utils.Draw.WinnerRank--));
                winnerRank.classList.add("winner-rank");
                winnerName.appendChild(document.createTextNode(winner.name));
                winnerName.classList.add("winner-name");
                winnerElement.appendChild(winnerRank);
                winnerElement.appendChild(winnerName);
                Utils.Elements.winnerList.insertBefore(winnerElement, Utils.Elements.winnerList.firstElementChild);
            }
        }
    },

    //RANDOM NUMBER GENERATOR
    Rand: {
        Int: function (min, max) {
            return Math.floor(Math.random() * (max - min)) + min;
        },
        Float: function (min, max) {
            return Math.random() * (max - min) + min;
        }
    },

    //BG EFFECTS
    Effects: {
        GenerateBGStars: function () {
            var width = window.innerWidth;
            var height = window.innerHeight;

            for (var i = 0; i < 80; i++) {
                var star = document.createElement("div");
                star.classList.add("star");
                star.style.top = Utils.Rand.Int(0, height) + "px";
                star.style.left = Utils.Rand.Int(0, width) + "px";
                var animationDuration = Utils.Rand.Int(2000, 10000);
                star.style.animation = "blink ease-in-out " + animationDuration + "ms infinite";
                Utils.Elements.background.appendChild(star);
            }
        },
        InitShootingStars: function () {
            //8 SHOOTING STARS
            for (var i = 0; i < 8; i++) {
                var startPos = { x: Utils.Rand.Int(100, window.innerWidth + 100), y: window.innerHeight };
                var endPos = { x: startPos.x - window.innerHeight - 100, y: startPos.y - window.innerHeight - 100 };
                var shootAnimation = [
                    { offset: 0.0, left: startPos.x + "px", bottom: startPos.y + "px" },
                    { offset: 0.1, left: endPos.x + "px", bottom: endPos.y + "px" },
                    { offset: 1.0, left: endPos.x + "px", bottom: endPos.y + "px" }
                ];
                var shootTiming = {
                    duration: Utils.Rand.Int(10000, 20000),
                    iterations: Infinity,
                    delay: Utils.Rand.Int(10000, 20000)
                    //delay: 0
                };

                var shootingStar = document.createElement("div");
                shootingStar.classList.add("shooting-star");
                shootingStar.animate(shootAnimation, shootTiming);
                Utils.Elements.background.appendChild(shootingStar);
            }
        },

    },

    //DATA
    Sequence: {
        Tier: [[], [], [], [], []],
        //Tier:   0,  1,  2,  3,  4
        Iterator: [
            {   //Tier 0
                JumpTarget: 300, Interval: 10, WinnerInterval: 2500, DrawEndDelay: 3000, JumpIntervalModifier: function () {
                    if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 5) {
                        Utils.Draw.Iterator.JumpInterval += 3;
                    }
                }
            },  //Tier 0
            {   //Tier 1
                JumpTarget: 300, Interval: 10, WinnerInterval: 2500, DrawEndDelay: 3000, JumpIntervalModifier: function () {
                    if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 10) {
                        Utils.Draw.Iterator.JumpInterval += 3;
                    }
                }
            },  //Tier 1
            {   //Tier 2
                JumpTarget: 300, Interval: 10, WinnerInterval: 2500, DrawEndDelay: 3000, JumpIntervalModifier: function () {
                    if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 10) {
                        Utils.Draw.Iterator.JumpInterval += 3;
                    }
                }
            },  //Tier 2
            {   //Tier 3
                JumpTarget: 200, Interval: 40, WinnerInterval: 3000, DrawEndDelay: 5000, JumpIntervalModifier: function () {
                    if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 15) {
                        Utils.Draw.Iterator.JumpInterval += 10;
                    }
                }
            },  //Tier 3
            {   //Tier 4
                JumpTarget: 250, Interval: 80, WinnerInterval: 8000, DrawEndDelay: 8000, JumpIntervalModifier: function () {
                    if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 40) {
                        Utils.Draw.Iterator.JumpInterval += 10;
                        if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 15) {
                            Utils.Draw.Iterator.JumpInterval += 20;
                            if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 10) {
                                Utils.Draw.Iterator.JumpInterval += 30;
                                console.log("JumpInterval : " + Utils.Draw.Iterator.JumpInterval);
                                //if (Utils.Draw.Iterator.JumpCounter_Target - Utils.Draw.Iterator.JumpCounter < 5) {
                                //    Utils.Draw.Iterator.JumpInterval += 50;
                                //    console.log("JumpInterval : " + Utils.Draw.Iterator.JumpInterval);
                                //}
                            }
                        }
                    }
                }
            }   //Tier 4
        ],
        WinnerList: [],
        Init: function () {
            Utils.Sequence.KnuthShuffle();

            //Utils.Sequence.Tier[0] = Utils.Sequence.WinnerList.slice(0, 10);
            //Utils.Sequence.Tier[1] = Utils.Sequence.WinnerList.slice(10, 20);
            //Utils.Sequence.Tier[2] = Utils.Sequence.WinnerList.slice(20, 35);
            //Utils.Sequence.Tier[3] = Utils.Sequence.WinnerList.slice(35, 40);
            //Utils.Sequence.Tier[4] = Utils.Sequence.WinnerList.slice(40, 45);

            Utils.Sequence.Tier[0] = Utils.Sequence.WinnerList.slice(0, 9);  //9
            Utils.Sequence.Tier[1] = Utils.Sequence.WinnerList.slice(9, 19); //10
            Utils.Sequence.Tier[2] = Utils.Sequence.WinnerList.slice(19, 34);//15
            Utils.Sequence.Tier[3] = Utils.Sequence.WinnerList.slice(34, 39);//5
            Utils.Sequence.Tier[4] = Utils.Sequence.WinnerList.slice(39, 44);//5

            //Utils.Sequence.Tier[0] = [
            //    { id: 36, name: "Ngiam Hung Chye" },
            //    { id: 43, name: "Zann Lee" },
            //    { id: 44, name: "Ooi Say Voon" },
            //    { id: 8, name: "Clea Goh" },
            //    { id: 0, name: "Shinji Hara", ex: true },
            //    { id: 1, name: "Kohei Yamawaki", ex: true },
            //    { id: 7, name: "Yuichi Monguchi", ex: true },
            //    { id: 9, name: "Joanne Chee" },
            //    { id: 10, name: "Ang Bee Leng" }
            //];

        },
        KnuthShuffle: function () {
            //CLONE ARRAY
            //for (var i = 0; i < Utils.NameList.length; i++) { Utils.Sequence.WinnerList[i] = Utils.NameList[i]; }
            Utils.Sequence.WinnerList = Utils.NameList.slice();

            for (var i = 0; i < Utils.Sequence.WinnerList.length; i++) {
                var randomIndex = Utils.Rand.Int(i, Utils.Sequence.WinnerList.length);
                var selection = Utils.Sequence.WinnerList[randomIndex];
                var extract = Utils.Sequence.WinnerList[i];
                //SWAP position
                Utils.Sequence.WinnerList[i] = selection;
                Utils.Sequence.WinnerList[randomIndex] = extract;
            }

            //Shift ex in list
            for (var i = 34; i <= 43; i++) {
                var selection = Utils.Sequence.WinnerList[i];
                if (selection.ex) {
                    var newIndex = Utils.Rand.Int(0, 34);
                    while (Utils.Sequence.WinnerList[newIndex].ex) {
                        newIndex = Utils.Rand.Int(0, 34);
                    }
                    var extract = Utils.Sequence.WinnerList[newIndex];
                    //SWAP
                    Utils.Sequence.WinnerList[i] = extract;
                    Utils.Sequence.WinnerList[newIndex] = selection;
                }
            }

            //console.log(Utils.Sequence.WinnerList);
        },

        ReloadWinnerList: function (data) {
            Utils.Sequence.WinnerList = data;
            Utils.Sequence.Tier[0] = Utils.Sequence.WinnerList.slice(0, 10);
            Utils.Sequence.Tier[1] = Utils.Sequence.WinnerList.slice(10, 20);
            Utils.Sequence.Tier[2] = Utils.Sequence.WinnerList.slice(20, 35);
            Utils.Sequence.Tier[3] = Utils.Sequence.WinnerList.slice(35, 40);
            Utils.Sequence.Tier[4] = Utils.Sequence.WinnerList.slice(40, 45);
            Utils.Draw.Init();
        },

        Animations: [
            //Tier 0
            {
                SingleWinner: [
                    { ox: null, oy: null, x: window.innerWidth / 2, y: 200, delay: 0, noLaunch: false }
                ],
                DrawEnd: [
                    { ox: null, oy: null, x: window.innerWidth / 2,     y: 100, delay: 0, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 3,     y: 50, delay: 300, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 3 * 2, y: 50, delay: 300, noLaunch: false },

                    { ox: window.innerWidth / 4, oy: window.innerHeight, x: window.innerWidth / 4, y: 50, delay: 800, noLaunch: false },
                    { ox: window.innerWidth / 4 * 2, oy: window.innerHeight, x: window.innerWidth / 4 * 2, y: 50, delay: 1000, noLaunch: false },
                    { ox: window.innerWidth / 4 * 3, oy: window.innerHeight, x: window.innerWidth / 4 * 3, y: 50, delay: 1200, noLaunch: false }
                ]
            },
            //Tier 1
            {
                SingleWinner: [
                    { ox: null, oy: null, x: window.innerWidth / 2, y: 200, delay: 0, noLaunch: false }
                ],
                DrawEnd: [
                    { ox: window.innerWidth / 5 * 1, oy: window.innerHeight, x: window.innerWidth / 5 * 1, y: 50, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 5 * 2, oy: window.innerHeight, x: window.innerWidth / 5 * 2, y: 50, delay: 300, noLaunch: false },
                    { ox: window.innerWidth / 5 * 3, oy: window.innerHeight, x: window.innerWidth / 5 * 3, y: 50, delay: 600, noLaunch: false },
                    { ox: window.innerWidth / 5 * 4, oy: window.innerHeight, x: window.innerWidth / 5 * 4, y: 50, delay: 900, noLaunch: false },
                    { ox: window.innerWidth / 5 * 3, oy: window.innerHeight, x: window.innerWidth / 5 * 3, y: 50, delay: 1200, noLaunch: false },
                    { ox: window.innerWidth / 5 * 2, oy: window.innerHeight, x: window.innerWidth / 5 * 2, y: 50, delay: 1500, noLaunch: false },
                    { ox: window.innerWidth / 5 * 1, oy: window.innerHeight, x: window.innerWidth / 5 * 1, y: 50, delay: 1800, noLaunch: false }
                ]
            },
            //Tier 2
            {
                SingleWinner: [
                    { ox: window.innerWidth / 3 * 1, oy: window.innerHeight, x: window.innerWidth / 3 * 1, y: 50, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 3 * 2, oy: window.innerHeight, x: window.innerWidth / 3 * 2, y: 50, delay: 0, noLaunch: false }
                ],
                DrawEnd: [
                    { ox: null, oy: null, x: window.innerWidth / 2, y: 50, delay: 0, noLaunch: false },

                    { ox: window.innerWidth / 3 * 1, oy: window.innerHeight, x: window.innerWidth / 3 * 1, y: 50, delay: 400, noLaunch: false },
                    { ox: window.innerWidth / 3 * 2, oy: window.innerHeight, x: window.innerWidth / 3 * 2, y: 50, delay: 400, noLaunch: false },

                    { ox: window.innerWidth / 6 * 1, oy: window.innerHeight, x: window.innerWidth / 6 * 1, y: 50, delay: 800, noLaunch: false },
                    { ox: window.innerWidth / 6 * 5, oy: window.innerHeight, x: window.innerWidth / 6 * 5, y: 50, delay: 800, noLaunch: false },

                    { ox: null, oy: null, x: window.innerWidth / 2 * 1, y: 100, delay: 1500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 6 * 1, y: 50, delay: 1500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 6 * 5, y: 50, delay: 1500, noLaunch: false }
                ]
            },
            //Tier 3
            {
                SingleWinner: [
                    { ox: null, oy: null, x: window.innerWidth / 2, y: 100, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 4 * 1, oy: window.innerHeight, x: window.innerWidth / 6 * 5, y: 150, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 4 * 3, oy: window.innerHeight, x: window.innerWidth / 6 * 1, y: 150, delay: 0, noLaunch: false }
                ],
                DrawEnd: [
                    { ox: window.innerWidth / 9 * 1, oy: window.innerHeight, x: window.innerWidth / 9 * 1, y: 50, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 9 * 2, oy: window.innerHeight, x: window.innerWidth / 9 * 2, y: 50, delay: 200, noLaunch: false },
                    { ox: window.innerWidth / 9 * 3, oy: window.innerHeight, x: window.innerWidth / 9 * 3, y: 50, delay: 400, noLaunch: false },
                    { ox: window.innerWidth / 9 * 4, oy: window.innerHeight, x: window.innerWidth / 9 * 4, y: 50, delay: 600, noLaunch: false },
                    { ox: window.innerWidth / 9 * 5, oy: window.innerHeight, x: window.innerWidth / 9 * 5, y: 50, delay: 800, noLaunch: false },
                    { ox: window.innerWidth / 9 * 6, oy: window.innerHeight, x: window.innerWidth / 9 * 6, y: 50, delay: 1000, noLaunch: false },
                    { ox: window.innerWidth / 9 * 7, oy: window.innerHeight, x: window.innerWidth / 9 * 7, y: 50, delay: 1200, noLaunch: false },
                    { ox: window.innerWidth / 9 * 8, oy: window.innerHeight, x: window.innerWidth / 9 * 8, y: 50, delay: 1400, noLaunch: false },

                    { ox: null, oy: null, x: 0, y: 0, delay: 2500, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth, y: 0, delay: 2500, noLaunch: true },

                    { ox: null, oy: null, x: window.innerWidth / 2, y: 0, delay: 3000, noLaunch: true },

                    { ox: null, oy: null, x: window.innerWidth / 4 * 1, y: 0, delay: 3500, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 4 * 3, y: 0, delay: 3500, noLaunch: true }

                ]
            },
            //Tier 4
            {
                SingleWinner: [
                    { ox: null, oy: null, x: window.innerWidth / 2, y: 100, delay: 2500, noLaunch: false },
                    { ox: window.innerWidth / 4 * 1, oy: window.innerHeight, x: window.innerWidth / 6 * 5, y: 150, delay: 2500, noLaunch: false },
                    { ox: window.innerWidth / 4 * 3, oy: window.innerHeight, x: window.innerWidth / 6 * 1, y: 150, delay: 2500, noLaunch: false }
                ],
                DrawEnd: [
                    { ox: window.innerWidth / 8 * 1, oy: window.innerHeight, x: window.innerWidth / 8 * 1, y: 50, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 8 * 7, oy: window.innerHeight, x: window.innerWidth / 8 * 7, y: 50, delay: 0, noLaunch: false },
                    { ox: window.innerWidth / 8 * 2, oy: window.innerHeight, x: window.innerWidth / 8 * 2, y: 50, delay: 500, noLaunch: false },
                    { ox: window.innerWidth / 8 * 6, oy: window.innerHeight, x: window.innerWidth / 8 * 6, y: 50, delay: 500, noLaunch: false },
                    { ox: window.innerWidth / 8 * 3, oy: window.innerHeight, x: window.innerWidth / 8 * 3, y: 50, delay: 1000, noLaunch: false },
                    { ox: window.innerWidth / 8 * 5, oy: window.innerHeight, x: window.innerWidth / 8 * 5, y: 50, delay: 1000, noLaunch: false },
                    { ox: window.innerWidth / 8 * 4, oy: window.innerHeight, x: window.innerWidth / 8 * 4, y: 50, delay: 1500, noLaunch: false },
                    { ox: window.innerWidth / 8 * 3.5, oy: window.innerHeight+100, x: window.innerWidth / 8 * 3.5, y: 150, delay: 1500, noLaunch: false },
                    { ox: window.innerWidth / 8 * 4.5, oy: window.innerHeight + 100, x: window.innerWidth / 8 * 4.5, y: 150, delay: 1500, noLaunch: false },

                    { ox: null, oy: null, x: window.innerWidth / 8 * 3, y: 0, delay: 2600, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 8 * 5, y: 0, delay: 2600, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 8 * 2, y: 0, delay: 2800, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 8 * 6, y: 0, delay: 2800, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 8 * 1, y: 0, delay: 3000, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth / 8 * 7, y: 0, delay: 3000, noLaunch: true },
                    { ox: null, oy: null, x: 0, y: 0, delay: 3200, noLaunch: true },
                    { ox: null, oy: null, x: window.innerWidth, y: 0, delay: 3200, noLaunch: true },

                    { ox: null, oy: null, x: 5, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 1, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 2, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 3, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 4, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 5, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 6, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 7, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 8, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 9, y: 50, delay: 3500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth - 5, y: 50, delay: 3500, noLaunch: false },

                    { ox: null, oy: null, x: 5, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 1, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 2, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 3, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 4, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 5, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 6, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 7, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 8, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 9, y: 50, delay: 4000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth - 5, y: 50, delay: 4000, noLaunch: false },

                    { ox: null, oy: null, x: 5, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 1, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 2, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 3, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 4, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 5, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 6, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 7, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 8, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 9, y: 50, delay: 4500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth - 5, y: 50, delay: 4500, noLaunch: false },

                    { ox: null, oy: null, x: 5, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 1, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 2, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 3, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 4, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 5, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 6, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 7, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 8, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 9, y: 50, delay: 5000, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth - 5, y: 50, delay: 5000, noLaunch: false },

                    { ox: null, oy: null, x: 5, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 1, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 2, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 3, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 4, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 5, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 6, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 7, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 8, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth / 10 * 9, y: 50, delay: 5500, noLaunch: false },
                    { ox: null, oy: null, x: window.innerWidth - 5, y: 50, delay: 5500, noLaunch: false }
                ]
            }
        ]

    },
    
    //Export Winner list
    Export: {
        GetWinnerListJSON: function () {
            var dataString = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(Utils.Sequence.WinnerList));
            var downloadElement = document.createElement("a");
            downloadElement.setAttribute("href", dataString);
            downloadElement.setAttribute("download", "winners.json");

            if (window.confirm("Download winner.json?")) {
                downloadElement.click();
            }
            downloadElement.remove();
        },
        GetRawList: function () {
            var winnerArray = Utils.Sequence.WinnerList.slice().reverse();
            var exportData = winnerArray.map((person, index) => (index + 1) + "," + person.name).reverse().join('\n');
            var dataString = "data:text/csv;charset=utf-8," + exportData;
            var downloadElement = document.createElement("a");
            downloadElement.setAttribute("href", dataString);
            downloadElement.setAttribute("download", "winners.csv");

            if (window.confirm("Download winner list?")) {
                downloadElement.click();
            }
            downloadElement.remove();
        }
    },
    Import: {
        TriggerFileInputClick: function () {
            Utils.Elements.fileInput.click();
        },
        FileInputChange: function (event) {
            //console.log(event.target.files[0]);
            var file = event.target.files[0];
            var fr = new window.FileReader();
            fr.onload = function () {
                Utils.Import.LoadWinnerListJSON(fr.result);
            };
            fr.readAsText(file);

        },
        LoadWinnerListJSON: function (fileData) {
            var data = JSON.parse(fileData);
            console.log(data);
            Utils.Sequence.ReloadWinnerList(data);
        }
    },

    NameList: [
        { id: 0, name: "Shinji Hara", ex: true },
        { id: 1, name: "Kohei Yamawaki", ex: true },
        { id: 2, name: "Yoshihiro Ohba", ex: true },
        { id: 3, name: "Shin Hyun Chul", ex: true },
        { id: 4, name: "Keisuke Nomoto", ex: true },
        { id: 5, name: "Yasushi Ogawa", ex: true },
        { id: 6, name: "Ryuta Uekado", ex: true },
        { id: 7, name: "Yuichi Monguchi", ex: true },
        { id: 8, name: "Clea Goh" },
        { id: 9, name: "Joanne Chee" },
        { id: 10, name: "Ang Bee Leng" },
        { id: 11, name: "Elayne Loke" },
        { id: 12, name: "Felicia Phung" },
        { id: 13, name: "Serene Lim" },
        { id: 14, name: "Katherine Lau" },
        { id: 15, name: "Yeo Guat Mui" },
        { id: 16, name: "Rebecca Chia" },
        { id: 17, name: "Teoh Kai Wei" },
        { id: 18, name: "Terence Lim" },
        { id: 19, name: "Aggie Wang" },
        { id: 20, name: "Fendi Chen" },
        { id: 21, name: "Ivy PY Lim" },
        { id: 22, name: "Kwan Ann Kay" },
        { id: 23, name: "Law Lee Nah" },
        { id: 24, name: "Xu Shuhua" },
        { id: 25, name: "Christine Wong" },
        { id: 26, name: "Ong Chuen Wee" },
        { id: 27, name: "Foo Chwan Kae" },
        { id: 28, name: "Jayle Lim" },
        { id: 29, name: "Leong Chow Yoke" },
        { id: 30, name: "Liew Chan Ming" },
        { id: 31, name: "Reuben Goh" },
        { id: 32, name: "Goh Lay San" },
        { id: 33, name: "Eileen Ng" },
        { id: 34, name: "Tracy Ng" },
        { id: 35, name: "Hannah Chen" },
        { id: 36, name: "Catherine Yan" },
        { id: 37, name: "Chloe Yong" },
        { id: 38, name: "Lau Ping Shi" },
        { id: 39, name: "Stephy Babu" },
        { id: 40, name: "Lok Eve Wei" },
        { id: 41, name: "Olivia Xiao" },
        { id: 42, name: "Zann Lee" },
        { id: 43, name: "Ooi Say Voon" }
        //{ id: 36, name: "Ngiam Hung Chye" }

    ]
}
